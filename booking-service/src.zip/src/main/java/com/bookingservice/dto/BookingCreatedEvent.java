package com.bookingservice.dto;

public class BookingCreatedEvent {

}
