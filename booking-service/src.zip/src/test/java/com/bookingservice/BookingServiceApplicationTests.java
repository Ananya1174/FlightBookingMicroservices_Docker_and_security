package com.bookingservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = com.bookingservice.BookingServiceApplication.class)
class BookingServiceApplicationTest {

    @Test
    void contextLoads() {
        // If the Spring context fails to start this will fail.
    }
}